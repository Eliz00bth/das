let currentSlides = { china: 0, japan: 0, korea: 0 };

function moveSlide(direction, category) {
    const images = document.querySelectorAll(`#${category}Images img`);
    currentSlides[category] = (currentSlides[category] + direction + images.length) % images.length;
    const translateX = -currentSlides[category] * 100;
    document.querySelector(`#${category}Images`).style.transform = `translateX(${translateX}%)`;
}

document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const name = document.getElementById('name').value;
    const phone = document.getElementById('phone').value;

    document.getElementById('formMessage').innerText = name && phone ? 'Форма отправлена' : 'Пожалуйста, заполните все поля.';
    if (name && phone) this.reset();
});